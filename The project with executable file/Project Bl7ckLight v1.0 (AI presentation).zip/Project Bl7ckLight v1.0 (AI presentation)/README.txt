This project contains an example of a First Person Shooter with a Weapons System and Enemy AI example


- Use W,A,S,D to move and Mouse View to look around
- Press 1, 2 to switch weapons
- Eliminate the waves of enemies that are spawned around

